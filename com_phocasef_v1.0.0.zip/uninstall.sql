DROP TABLE IF EXISTS `#__phocasef_url`;
DROP TABLE IF EXISTS `#__phocasef_ref`;
