<?php
/*********** XML PARAMETERS AND VALUES ************/
$xml_item = "component";// component | template
$xml_file = "phocasef.xml";		
$xml_name = "PhocaSEF";
$xml_creation_date = "18/12/2008";
$xml_author = "Jan Pavelka (www.phoca.cz)";
$xml_author_email = "info@phoca.cz";
$xml_author_url = "www.phoca.cz";
$xml_copyright = "Jan Pavelka";
$xml_license = "GNU/GPL";
$xml_version = "1.0.0 beta";
$xml_description = "Phoca SEF";
$xml_copy_file = 1;//Copy other files in to administration area (only for development), ./front, ./language, ./other

$xml_menu = array (0 => "Phoca SEF", 1 => "option=com_phocasef", 2 => "components/com_phocasef/assets/images/icon-16-menu.png");
$xml_submenu[0] = array (0 => "Phoca Control Panel", 1 => "option=com_phocasef", 2 => "components/com_phocasef/assets/images/icon-16-control-panel.png");
$xml_submenu[1] = array (0 => "Phoca Redirect Site", 1 => "option=com_phocasef&view=phocasefurls", 2 => "components/com_phocasef/assets/images/icon-16-menu-red.png");
$xml_submenu[2] = array (0 => "Phoca Referring Sites", 1 => "option=com_phocasef&view=phocasefrefs", 2 => "components/com_phocasef/assets/images/icon-16-menu-ref.png");
$xml_submenu[3] = array (0 => "Phoca Info", 1 => "option=com_phocasef&view=phocainfo", 2 => "components/com_phocasef/assets/images/icon-16-menu-info.png");

$xml_install_file = 'install.phocasef.php'; 
$xml_uninstall_file = 'uninstall.phocasef.php';
/*********** XML PARAMETERS AND VALUES ************/
?>